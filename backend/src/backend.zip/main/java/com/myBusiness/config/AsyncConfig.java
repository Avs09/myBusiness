package com.myBusiness.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.scheduling.annotation.EnableAsync;

import java.util.concurrent.Executor;

/**
 * AsyncConfig configures asynchronous processing for the application.
 * It defines a ThreadPoolTaskExecutor to be used by methods annotated with @Async.
 */
@Configuration
@EnableAsync
public class AsyncConfig {

    /**
     * Defines the Executor bean that handles asynchronous tasks.
     * 
     * @return The configured Executor.
     */
    @Bean(name = "taskExecutor")
    public Executor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        // Configure core pool size, max pool size, and queue capacity as needed
        executor.setCorePoolSize(2);
        executor.setMaxPoolSize(5);
        executor.setQueueCapacity(500);
        executor.setThreadNamePrefix("AsyncThread-");
        executor.initialize();
        return executor;
    }
}
