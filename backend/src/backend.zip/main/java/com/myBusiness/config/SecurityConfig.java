package com.myBusiness.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.myBusiness.service.impl.UserDetailsServiceImpl;
import com.myBusiness.util.JwtAuthEntryPoint;
import com.myBusiness.util.JwtAuthFilter;
import com.myBusiness.util.JwtUtil;

/**
 * SecurityConfig sets up Spring Security for the application.
 * It configures stateless authentication using JWT and disables CSRF.
 */
@Configuration
public class SecurityConfig {

    // Custom user details service to load user-specific data during authentication
    private final UserDetailsServiceImpl userDetailsService;
    // Entry point to handle unauthorized access attempts
    private final JwtAuthEntryPoint jwtAuthEntryPoint;
    // Utility for handling JWT token operations
    private final JwtUtil jwtUtil;

    /**
     * Constructor to inject dependencies.
     */
    public SecurityConfig(UserDetailsServiceImpl userDetailsService, 
                          JwtAuthEntryPoint jwtAuthEntryPoint,
                          JwtUtil jwtUtil) {
        this.userDetailsService = userDetailsService;
        this.jwtAuthEntryPoint = jwtAuthEntryPoint;
        this.jwtUtil = jwtUtil;
    }

    /**
     * Configures the HTTP security including endpoints access, exception handling, and session management.
     * Adds a custom JWT filter to process and validate tokens.
     */
    @Bean
    protected SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // Disable CSRF as JWT is used for stateless authentication
            .csrf(csrf -> csrf.disable())
            // Define public and protected endpoints
            .authorizeHttpRequests(request -> request
                // Allow public access to auth endpoints and Swagger documentation endpoints
                .requestMatchers("/api/auth/**", "/swagger-ui/**", "/v3/api-docs/**").permitAll()
                // Secure all other endpoints
                .anyRequest().authenticated()
            )
            // Configure custom handling for unauthorized requests
            .exceptionHandling(exceptions -> exceptions
                .authenticationEntryPoint(jwtAuthEntryPoint)
            )
            // Use stateless session management since JWT handles session information
            .sessionManagement(session -> session
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            );

        // Insert the custom JWT authentication filter before the standard authentication filter
        http.addFilterBefore(jwtAuthFilter(), UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    /**
     * Configures the AuthenticationManager with the custom UserDetailsService and password encoder.
     */
    @Bean
    protected AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        AuthenticationManagerBuilder authBuilder = http.getSharedObject(AuthenticationManagerBuilder.class);
        authBuilder
            .userDetailsService(userDetailsService)
            .passwordEncoder(passwordEncoder());
        return authBuilder.build();
    }

    /**
     * Defines the password encoder bean using BCrypt algorithm.
     */
    @Bean
    protected PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * Creates an instance of the custom JWT authentication filter.
     */
    @Bean
    protected JwtAuthFilter jwtAuthFilter() {
        return new JwtAuthFilter(jwtUtil, userDetailsService);
    }
}
