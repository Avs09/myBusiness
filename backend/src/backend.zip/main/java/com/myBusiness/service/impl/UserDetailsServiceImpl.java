package com.myBusiness.service.impl;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.myBusiness.model.User;
import com.myBusiness.repository.UserRepository;

import java.util.stream.Collectors;

/**
 * UserDetailsServiceImpl implements the Spring Security UserDetailsService interface.
 * It loads user-specific data (including roles and credentials) from the repository for authentication.
 */
@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UserRepository userRepository;

    /**
     * Constructor for dependency injection.
     */
    public UserDetailsServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Loads the user by email, constructs and returns a Spring Security UserDetails object.
     * @param email The email of the user.
     * @return UserDetails instance containing the user's credentials and authorities.
     * @throws UsernameNotFoundException If the user is not found.
     */
    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));

        return org.springframework.security.core.userdetails.User.builder()
                .username(user.getEmail())
                .password(user.getPassword())
                .authorities(user.getRoles().stream()
                        .map(role -> "ROLE_" + role.getName())
                        .collect(Collectors.toList()).toArray(new String[0]))
                .build();
    }
}
