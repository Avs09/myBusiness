package com.myBusiness.service;

import com.myBusiness.model.Product;
import com.myBusiness.model.User;
import com.myBusiness.model.InventoryMovement;

import java.math.BigDecimal;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * InventoryService defines the contract for all inventory-related operations.
 * It includes methods to manage products and to record inventory movements.
 */
public interface InventoryService {
    
    /**
     * Adds a new product to the inventory.
     * @param product The product to add.
     * @return The saved product.
     */
    Product addProduct(Product product);
    
    /**
     * Updates an existing product identified by its ID.
     * @param id The unique identifier of the product.
     * @param product The updated product information.
     * @return The updated product.
     */
    Product updateProduct(Long id, Product product);
    
    /**
     * Deletes a product from the inventory using its ID.
     * @param id The unique identifier of the product to delete.
     */
    void deleteProduct(Long id);
    
    /**
     * Retrieves a paginated list of all products.
     * @param pageable Pagination information.
     * @return A page of products.
     */
    Page<Product> getAllProducts(Pageable pageable);
    
    /**
     * Searches for products by name with pagination.
     * @param name The product name filter.
     * @param pageable Pagination information.
     * @return A page of products matching the name.
     */
    Page<Product> getProductsByName(String name, Pageable pageable);
    
    /**
     * Retrieves products within a specified price range.
     * @param minPrice The minimum price.
     * @param maxPrice The maximum price.
     * @param pageable Pagination information.
     * @return A page of products in the price range.
     */
    Page<Product> getProductsByPriceRange(BigDecimal minPrice, BigDecimal maxPrice, Pageable pageable);
    
    /**
     * Retrieves a single product by its ID.
     * @param id The unique identifier of the product.
     * @return The product details.
     */
    Product getProductById(Long id);
    
    /**
     * Records an inventory movement (e.g., stock addition or removal).
     * @param productId The product's ID.
     * @param quantity The quantity involved in the movement.
     * @param type The type of movement (e.g., "ENTRADA" for addition, "SALIDA" for removal).
     * @param reason The reason for the movement.
     * @param comment Additional comments regarding the movement.
     * @param user The user performing the operation.
     * @return The recorded inventory movement.
     */
    InventoryMovement addMovement(Long productId, Integer quantity, String type, String reason, String comment, User user);
    
    /**
     * Retrieves a paginated list of inventory movements.
     * @param pageable Pagination information.
     * @return A page of inventory movements.
     */
    Page<InventoryMovement> getAllMovements(Pageable pageable);
}
