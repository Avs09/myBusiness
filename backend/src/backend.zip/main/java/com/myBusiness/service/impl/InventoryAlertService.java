package com.myBusiness.service.impl;

import com.myBusiness.model.Product;
import com.myBusiness.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * InventoryAlertService periodically checks for products with low inventory
 * and sends an email alert listing the affected products.
 */
@Service
public class InventoryAlertService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private JavaMailSender mailSender;

    // Threshold value for low inventory
    private static final int THRESHOLD = 10;

    /**
     * Scheduled method that runs daily at 9:00 AM.
     * It finds products with quantities below the threshold and triggers an email alert.
     */
    @Scheduled(cron = "0 0 9 * * ?")  // Executes every day at 9:00 AM
    public void checkLowStockAndSendAlerts() {
        List<Product> lowStockProducts = productRepository.findByQuantityLessThan(THRESHOLD);

        if (!lowStockProducts.isEmpty()) {
            sendLowStockAlert(lowStockProducts);
        }
    }

    /**
     * Constructs and sends a simple email alert containing a list of low stock products asynchronously.
     *
     * @param lowStockProducts List of products with inventory below the threshold.
     */
    @Async("taskExecutor")
    private void sendLowStockAlert(List<Product> lowStockProducts) {
        StringBuilder messageBody = new StringBuilder("Low Stock Products:\n");

        // Append product details to the email body
        for (Product product : lowStockProducts) {
            messageBody.append("ID: ").append(product.getId())
                       .append(", Name: ").append(product.getName())
                       .append(", Quantity: ").append(product.getQuantity())
                       .append("\n");
        }

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo("correo_responsable@example.com");  // Update with actual recipient email
        message.setSubject("Alert: Low Inventory");
        message.setText(messageBody.toString());
        message.setFrom("tu_correo@gmail.com");  // Update with the sender's email

        mailSender.send(message);
    }
}
