package com.myBusiness.service;

import com.myBusiness.dto.AuthResponse;
import com.myBusiness.dto.LoginRequest;
import com.myBusiness.dto.RegisterRequest;
import com.myBusiness.dto.UpdateUserRequest;

/**
 * AuthService interface defines the contract for authentication-related operations.
 * Implementations of this service should handle user registration, authentication,
 * user updates, deletion, and token renewal.
 */
public interface AuthService {
    /**
     * Registers a new user using the provided registration details.
     */
    void register(RegisterRequest request);

    /**
     * Authenticates a user using the login request details.
     * @return an AuthResponse containing JWT tokens.
     */
    AuthResponse authenticate(LoginRequest request);

    /**
     * Updates the user details for the given user ID.
     * Requires a valid current user role for authorization.
     */
    void updateUser(Long id, UpdateUserRequest request, String currentUserRole);

    /**
     * Deletes the user with the specified ID.
     * Requires a valid current user role for authorization.
     */
    void deleteUser(Long id, String currentUserRole);

    /**
     * Renews the access token using the provided refresh token.
     * @return the new access token.
     */
    String renewAccessToken(String refreshToken);
    
    void logout(String refreshToken);
}
