package com.myBusiness.service;

import org.springframework.core.io.Resource;

import java.io.IOException;
import java.io.OutputStream;

/**
 * ReporteService defines the contract for generating various types of reports.
 * It supports generating reports for products, movements, and low stock inventories in different formats.
 */
public interface ReporteService {
    
    /**
     * Generates a report based on the specified type and format.
     * @param reportType The type of report (e.g., "PRODUCTOS", "MOVIMIENTOS", "INVENTARIOS_BAJOS").
     * @param format The format of the report (e.g., "PDF", "EXCEL").
     * @return A Resource containing the generated report.
     * @throws IOException If an error occurs during report generation.
     */
    Resource generarReporte(String reportType, String format) throws IOException;
    
    /**
     * Generates a low stock report and writes it to the provided OutputStream.
     * @param outputStream The stream to which the report will be written.
     */
    void generateLowStockReport(OutputStream outputStream);
    
    /**
     * Generates a low stock report and returns it as a byte array.
     * @return Byte array representation of the low stock report.
     * @throws IOException If an error occurs during report generation.
     */
    byte[] generateLowStockReportAsByteArray() throws IOException;
}
