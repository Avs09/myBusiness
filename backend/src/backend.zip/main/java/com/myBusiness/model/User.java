package com.myBusiness.model;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

/**
 * User is a JPA entity representing an application user.
 * It includes credentials and a set of roles for access control.
 */
@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Unique email used as the username
    @Column(unique = true, nullable = false)
    private String email;

    // Encrypted user password
    @Column(nullable = false)
    private String password;

    // Eagerly load roles; a user can have multiple roles with a many-to-many relationship
    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinTable(
        name = "user_roles",
        joinColumns = @JoinColumn(name = "user_id"),
        inverseJoinColumns = @JoinColumn(name = "role_id")
    )
    private Set<Role> roles = new HashSet<>();

    // Getters and setters

    /**
     * @return the user's unique identifier.
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the user's unique identifier.
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the user's email.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the user's email.
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the user's encrypted password.
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the user's encrypted password.
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the set of roles associated with the user.
     */
    public Set<Role> getRoles() {
        return roles;
    }

    /**
     * Sets the roles for the user.
     */
    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }
}
