package com.myBusiness.model;

import jakarta.persistence.*;
import java.time.Instant;

/**
 * RefreshToken is a JPA entity representing a refresh token.
 * It is linked to a user and contains token details and an expiry date.
 */
@Entity
public class RefreshToken {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // One-to-one association with a User; each refresh token is linked to a single user
    @OneToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    // Unique token string used for refreshing the access token
    @Column(nullable = false, unique = true)
    private String token;

    // The expiry date and time for the refresh token
    @Column(nullable = false)
    private Instant expiryDate;

    // Getters and setters

    /**
     * @return the refresh token's unique identifier.
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the refresh token's unique identifier.
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the associated user.
     */
    public User getUser() {
        return user;
    }

    /**
     * Sets the user associated with this token.
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     * @return the token string.
     */
    public String getToken() {
        return token;
    }

    /**
     * Sets the token string.
     */
    public void setToken(String token) {
        this.token = token;
    }

    /**
     * @return the token expiry date.
     */
    public Instant getExpiryDate() {
        return expiryDate;
    }

    /**
     * Sets the token expiry date.
     */
    public void setExpiryDate(Instant expiryDate) {
        this.expiryDate = expiryDate;
    }
}
