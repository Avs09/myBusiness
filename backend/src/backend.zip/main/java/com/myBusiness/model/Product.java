package com.myBusiness.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

/**
 * Product is a JPA entity representing a product in the inventory.
 * It includes details such as name, description, quantity, and price.
 * The @Version field is used for optimistic locking to handle concurrent updates.
 */
@Entity
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Unique product name used to identify the product
    @Column(nullable = false, unique = true)
    private String name;

    // Detailed description of the product
    @Column(nullable = false)
    private String description;

    // Available quantity in stock
    @Column(nullable = false)
    private Integer quantity;

    // Price of the product
    @Column(nullable = false)
    private BigDecimal price;

    // Version field for optimistic locking
    @Version
    private Integer version;

    // Getters and setters

    /**
     * @return the product's unique identifier.
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the product's unique identifier.
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the product name.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the product name.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the product description.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the product description.
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the quantity in stock.
     */
    public Integer getQuantity() {
        return quantity;
    }

    /**
     * Sets the available quantity.
     */
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    /**
     * @return the price of the product.
     */
    public BigDecimal getPrice() {
        return price;
    }

    /**
     * Sets the price of the product.
     */
    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    /**
     * @return the version number used for optimistic locking.
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * Sets the version number used for optimistic locking.
     */
    public void setVersion(Integer version) {
        this.version = version;
    }
}
