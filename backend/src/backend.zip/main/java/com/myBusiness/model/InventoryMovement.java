package com.myBusiness.model;

import java.time.Instant;

import jakarta.persistence.*;

/**
 * InventoryMovement is a JPA entity that records changes in product inventory.
 * It logs both stock additions ("ENTRADA") and removals ("SALIDA"), along with details like date, reason, and comments.
 */
@Entity
public class InventoryMovement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Many-to-one relationship linking the movement to a product
    @ManyToOne
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;

    // Many-to-one relationship linking the movement to a user who performed the action
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    // The quantity of product moved
    @Column(nullable = false)
    private Integer quantity;

    // Movement type indicating stock entry or exit
    @Column(nullable = false)
    private String type; // "ENTRADA" (entry) or "SALIDA" (exit)

    // The date and time when the movement occurred
    @Column(nullable = false)
    private Instant date;

    // Reason for the movement (optional, up to 500 characters)
    @Column(length = 500)
    private String reason;

    // Additional comments (optional, up to 500 characters)
    @Column(length = 500)
    private String comment;

    // Getters and setters

    /**
     * @return the movement ID.
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the movement ID.
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the associated product.
     */
    public Product getProduct() {
        return product;
    }

    /**
     * Sets the associated product.
     */
    public void setProduct(Product product) {
        this.product = product;
    }

    /**
     * @return the user who performed the movement.
     */
    public User getUser() {
        return user;
    }

    /**
     * Sets the user who performed the movement.
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     * @return the quantity moved.
     */
    public Integer getQuantity() {
        return quantity;
    }

    /**
     * Sets the quantity moved.
     */
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    /**
     * @return the movement type.
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the movement type.
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the date of the movement.
     */
    public Instant getDate() {
        return date;
    }

    /**
     * Sets the date of the movement.
     */
    public void setDate(Instant date) {
        this.date = date;
    }

    /**
     * @return the reason for the movement.
     */
    public String getReason() {
        return reason;
    }

    /**
     * Sets the reason for the movement.
     */
    public void setReason(String reason) {
        this.reason = reason;
    }

    /**
     * @return any additional comments.
     */
    public String getComment() {
        return comment;
    }

    /**
     * Sets additional comments.
     */
    public void setComment(String comment) {
        this.comment = comment;
    }
}
