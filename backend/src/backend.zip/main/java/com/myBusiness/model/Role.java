package com.myBusiness.model;

import jakarta.persistence.*;

/**
 * Role is a JPA entity representing a user role in the system.
 * It stores a unique role name used for access control.
 */
@Entity
@Table(name = "roles")
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Unique name of the role (e.g., ROLE_ADMIN, ROLE_USER)
    @Column(unique = true, nullable = false)
    private String name;

    // Getters and setters

    /**
     * @return the role's unique identifier.
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the role's unique identifier.
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the name of the role.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the role.
     */
    public void setName(String name) {
        this.name = name;
    }
}
