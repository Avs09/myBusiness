package com.myBusiness.util;

/**
 * DataSanitizer provides utility methods for sanitizing input data.
 * It removes potentially harmful HTML tags and trims leading and trailing whitespace.
 */
public class DataSanitizer {

    /**
     * Sanitizes the given input string by removing HTML tags and trimming whitespace.
     *
     * @param input The string to sanitize.
     * @return A sanitized version of the input string, or null if the input is null.
     */
    public static String sanitize(String input) {
        if (input == null) {
            return null;
        }
        // Simple approach to remove HTML tags and trim the string.
        return input.replaceAll("<.*?>", "").trim();
    }
}
