package com.myBusiness.dto;

/**
 * AuthResponse is a Data Transfer Object (DTO) for returning JWT tokens after authentication.
 * It contains both the access token and the refresh token.
 */
public class AuthResponse {

    private String accessToken;
    private String refreshToken;

    /**
     * Constructor to initialize both tokens.
     */
    public AuthResponse(String accessToken, String refreshToken) {
        this.accessToken = accessToken;
        this.refreshToken = refreshToken;
    }

    // Getters and setters for access and refresh tokens

    /**
     * @return the access token.
     */
    public String getAccessToken() {
        return accessToken;
    }

    /**
     * Sets a new access token.
     */
    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    /**
     * @return the refresh token.
     */
    public String getRefreshToken() {
        return refreshToken;
    }

    /**
     * Sets a new refresh token.
     */
    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }
}
