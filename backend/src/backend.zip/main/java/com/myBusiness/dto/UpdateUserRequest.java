package com.myBusiness.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.Set;

/**
 * UpdateUserRequest DTO is used to update user details such as email and roles.
 * It ensures that the email is valid and at least one role is provided.
 */
public class UpdateUserRequest {

    @NotBlank(message = "El email no puede estar vacío.")
    @Email(message = "El email debe tener un formato válido.")
    @Size(max = 255, message = "El email no puede exceder los 255 caracteres.")
    private String email;

    @NotNull(message = "Los roles no pueden ser nulos.")
    @Size(min = 1, message = "Debe asignarse al menos un rol.")
    private Set<@NotNull(message = "El ID del rol no puede ser nulo.") Long> roles;

    // Getters and setters

    /**
     * @return the updated email address.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the new email address.
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the set of role IDs to assign to the user.
     */
    public Set<Long> getRoles() {
        return roles;
    }

    /**
     * Sets the roles for the user.
     */
    public void setRoles(Set<Long> roles) {
        this.roles = roles;
    }
}
