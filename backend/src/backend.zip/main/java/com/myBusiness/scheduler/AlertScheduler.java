package com.myBusiness.scheduler;

import com.myBusiness.service.ReporteService;
import com.myBusiness.service.impl.AlertService;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * AlertScheduler is a scheduled job component that runs daily.
 * It generates a low stock report and sends alerts via email if inventory is low.
 */
@Component
public class AlertScheduler {

    // Service to generate reports (e.g., low stock report)
    private final ReporteService reporteService;
    // Service to handle sending email alerts
    private final AlertService alertService;

    /**
     * Constructor for dependency injection.
     */
    public AlertScheduler(ReporteService reporteService, AlertService alertService) {
        this.reporteService = reporteService;
        this.alertService = alertService;
    }

    /**
     * Scheduled job to execute daily at 8:00 AM.
     * It generates a low stock report and sends email alerts.
     */
    @Scheduled(cron = "0 0 8 * * ?") // Executes at 8:00 AM every day
    public void sendLowStockAlerts() {
        try {
            // Generate the low stock report as a byte array
            byte[] reportData = reporteService.generateLowStockReportAsByteArray();
            // Send an alert email with the report attached
            alertService.sendLowStockAlert(reportData);
        } catch (IOException e) {
            // Log any exceptions encountered during report generation or email sending
            System.err.println("Error al generar o enviar el reporte de inventarios bajos: " + e.getMessage());
        }
    }
}
