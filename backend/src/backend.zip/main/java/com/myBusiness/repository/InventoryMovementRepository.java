package com.myBusiness.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import com.myBusiness.model.InventoryMovement;

/**
 * Repository interface for InventoryMovement entities.
 * Extends JpaRepository to provide CRUD operations and pagination support.
 */
public interface InventoryMovementRepository extends JpaRepository<InventoryMovement, Long> {
    // Inherited methods provide support for CRUD and pagination.
    Page<InventoryMovement> findAll(Pageable pageable);
}
