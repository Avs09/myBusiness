package com.myBusiness.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.myBusiness.model.User;

import java.util.Optional;

/**
 * Repository interface for User entities.
 * Provides methods for user lookup and existence checks by email.
 */
public interface UserRepository extends JpaRepository<User, Long> {
    /**
     * Finds a user by email.
     */
    Optional<User> findByEmail(String email);

    /**
     * Checks if a user exists with the given email.
     */
    boolean existsByEmail(String email);
}
