package com.myBusiness.repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import com.myBusiness.model.Product;

/**
 * Repository interface for Product entities.
 * Provides additional query methods to search by name, price range, and stock quantity.
 */
public interface ProductRepository extends JpaRepository<Product, Long> {
    /**
     * Finds a product by its unique name.
     */
    Optional<Product> findByName(String name);
    
    /**
     * Retrieves all products with pagination.
     */
    Page<Product> findAll(Pageable pageable);
    
    /**
     * Retrieves products with prices within a specific range.
     */
    Page<Product> findByPriceBetween(BigDecimal minPrice, BigDecimal maxPrice, Pageable pageable);

    /**
     * Searches for products whose names contain the specified keyword, ignoring case.
     */
    Page<Product> findByNameContainingIgnoreCase(String name, Pageable pageable);
    
    /**
     * Finds all products with quantity less than the specified amount.
     */
    List<Product> findByQuantityLessThan(int quantity);
}
