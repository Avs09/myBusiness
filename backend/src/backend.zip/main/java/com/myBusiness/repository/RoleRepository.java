package com.myBusiness.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.myBusiness.model.Role;

import java.util.Optional;

/**
 * Repository interface for Role entities.
 * Provides a method to retrieve a role by its name.
 */
public interface RoleRepository extends JpaRepository<Role, Long> {
    /**
     * Finds a role by its name.
     */
    Optional<Role> findByName(String name);
}
