package com.myBusiness.repository;

import com.myBusiness.model.RefreshToken;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * Repository interface for RefreshToken entities.
 * Provides methods to find tokens by value and delete tokens by user ID.
 */
public interface RefreshTokenRepository extends JpaRepository<RefreshToken, Long> {
    /**
     * Finds a refresh token by its token string.
     */
    Optional<RefreshToken> findByToken(String token);

    /**
     * Deletes refresh tokens associated with a specific user.
     */
    void deleteByUserId(Long userId);
}
