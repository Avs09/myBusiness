package com.myBusiness.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * TestController provides a basic endpoint for testing the API definition.
 */
@RestController
public class TestController {

    /**
     * A simple endpoint to verify that the API is being scanned.
     * @return A welcome message.
     */
    @GetMapping("/test")
    public String test() {
        return "API is working!";
    }
}
