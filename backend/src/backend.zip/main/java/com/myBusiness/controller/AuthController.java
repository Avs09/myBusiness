package com.myBusiness.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.myBusiness.dto.AuthResponse;
import com.myBusiness.dto.LoginRequest;
import com.myBusiness.dto.RegisterRequest;
import com.myBusiness.service.AuthService;

/**
 * AuthController exposes REST endpoints for authentication-related operations.
 * These include login, registration, token renewal, user update, deletion, and logout.
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    // Service to handle authentication logic
    private final AuthService authService;

    /**
     * Constructor for dependency injection.
     */
    public AuthController(AuthService authService) {
        this.authService = authService;
    }
    
    /**
     * Endpoint to authenticate the user and obtain a JWT token.
     * @param loginRequest The login request payload containing email and password.
     * @return A response containing the access token and refresh token.
     */
    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody LoginRequest loginRequest) {
        AuthResponse response = authService.authenticate(loginRequest);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Endpoint to register a new user.
     * @param registerRequest The registration request payload.
     * @return A confirmation message upon successful registration.
     */
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody RegisterRequest registerRequest) {
        authService.register(registerRequest);
        return ResponseEntity.ok("Usuario registrado exitosamente.");
    }
    
    /**
     * Endpoint to renew the access token using a provided refresh token.
     * @param refreshToken The refresh token to be exchanged.
     * @return A response containing the new access token along with the refresh token.
     */
    @PostMapping("/refresh-token")
    public ResponseEntity<AuthResponse> renewAccessToken(@RequestBody String refreshToken) {
        String newAccessToken = authService.renewAccessToken(refreshToken);
        return ResponseEntity.ok(new AuthResponse(newAccessToken, refreshToken));
    }
    
    /**
     * Endpoint to log out a user by invalidating the refresh token.
     * @param refreshToken The refresh token to be invalidated.
     * @return A confirmation message upon successful logout.
     */
    @PostMapping("/logout")
    public ResponseEntity<String> logout(@RequestBody String refreshToken) {
        authService.logout(refreshToken);
        return ResponseEntity.ok("Logout exitoso.");
    }
    
    /**
     * Endpoint to update a user's details.
     * Requires a valid user role to authorize the update.
     * @param id The ID of the user to be updated.
     * @param request The update request payload.
     * @param currentUserRole The role of the current user performing the update.
     * @return A confirmation message.
     */
    @PutMapping("/users/{id}")
    public ResponseEntity<String> updateUser(@PathVariable Long id, @RequestBody RegisterRequest request, @RequestHeader("Role") String currentUserRole) {
        authService.updateUser(id, request, currentUserRole);
        return ResponseEntity.ok("Usuario actualizado con éxito.");
    }

    /**
     * Endpoint to delete a user.
     * Requires a valid user role to authorize the deletion.
     * @param id The ID of the user to be deleted.
     * @param currentUserRole The role of the current user performing the deletion.
     * @return A confirmation message.
     */
    @DeleteMapping("/users/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable Long id, @RequestHeader("Role") String currentUserRole) {
        authService.deleteUser(id, currentUserRole);
        return ResponseEntity.ok("Usuario eliminado con éxito.");
    }
}
