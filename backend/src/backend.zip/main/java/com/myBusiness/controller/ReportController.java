package com.myBusiness.controller;

import com.myBusiness.service.ReporteService;

import jakarta.servlet.http.HttpServletResponse;

import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

/**
 * ReportController provides endpoints to generate and download reports.
 * It supports different report types (e.g., low stock, products, movements) and formats (PDF, EXCEL).
 */
@RestController
@RequestMapping("/api/reports")
public class ReportController {

    // Service to handle report generation logic
    private final ReporteService reporteService;

    /**
     * Constructor for dependency injection.
     */
    public ReportController(ReporteService reporteService) {
        this.reporteService = reporteService;
    }

    /**
     * Endpoint to generate and download a low stock report in Excel format.
     * The response content type and header are set for file download.
     * @param response HttpServletResponse used to write the file output.
     * @throws IOException if an error occurs during report generation or output.
     */
    @GetMapping("/low-stock")
    public void generateLowStockReport(HttpServletResponse response) throws IOException {
        // Set the response content type for Excel file download
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=low_stock_report.xlsx");
        // Generate the low stock report and write it to the response output stream
        reporteService.generateLowStockReport(response.getOutputStream());
    }

    /**
     * Endpoint to generate a report based on the specified type and format.
     * Supports file download with appropriate HTTP headers.
     * @param reportType The type of report to generate.
     * @param format The format of the report (default is EXCEL).
     * @return ResponseEntity containing the generated report as a downloadable resource.
     */
    @GetMapping
    public ResponseEntity<Resource> generateReport(
            @RequestParam String reportType,
            @RequestParam(defaultValue = "EXCEL") String format) {

        try {
            // Generate the report using the specified parameters
            Resource report = reporteService.generarReporte(reportType, format);

            // Build a filename using the report type and format
            String filename = String.format("%s_report.%s", reportType.toLowerCase(), format.toLowerCase());
            return ResponseEntity.ok()
                    // Set header to prompt file download
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                    // Set the appropriate content type based on the format
                    .contentType(format.equalsIgnoreCase("EXCEL") ?
                            MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") :
                            MediaType.APPLICATION_OCTET_STREAM)
                    .body(report);
        } catch (IllegalArgumentException e) {
            // Return a bad request response if an invalid argument is provided
            return ResponseEntity.badRequest().body(null);
        } catch (UnsupportedOperationException e) {
            // Return a 415 Unsupported Media Type response for unsupported formats
            return ResponseEntity.status(415).body(null);
        } catch (IOException e) {
            // Return an internal server error response in case of IO exceptions
            return ResponseEntity.internalServerError().body(null);
        }
    }
}
