// src/main/java/com/myBusiness/application/exception/ImportExportException.java
package com.myBusiness.application.exception;

public class ImportExportException extends RuntimeException {
    public ImportExportException(String message, Throwable cause) {
        super(message, cause);
    }
}
