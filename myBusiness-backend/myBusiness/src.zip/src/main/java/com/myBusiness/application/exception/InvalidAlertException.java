// src/main/java/com/myBusiness/application/exception/InvalidAlertException.java
package com.myBusiness.application.exception;

public class InvalidAlertException extends RuntimeException {
    public InvalidAlertException(String msg) { super(msg); }
}

