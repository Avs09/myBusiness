// src/main/java/com/myBusiness/application/exception/AlertNotFoundException.java
package com.myBusiness.application.exception;

public class AlertNotFoundException extends RuntimeException {
    public AlertNotFoundException(String msg) { super(msg); }
}
