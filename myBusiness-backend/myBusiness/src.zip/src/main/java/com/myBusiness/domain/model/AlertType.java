// src/main/java/com/myBusiness/domain/model/AlertType.java
package com.myBusiness.domain.model;

public enum AlertType {
    UNDERSTOCK,
    OVERSTOCK;
}
