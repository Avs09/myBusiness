// src/main/java/com/myBusiness/application/exception/InvalidUnitException.java
package com.myBusiness.application.exception;

public class InvalidUnitException extends RuntimeException {
    public InvalidUnitException(String message) {
        super(message);
    }
}
